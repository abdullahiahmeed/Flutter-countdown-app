# Flutter Countdown App

A simple countdown applicated created using dart and flutter. the allows you to pick a time in hours and seconds and it will count down from that time to 0.

## 📷 Screen Shots

|![Flutter countdown app](./screenshot/1.png) | ![android countdown app](./screenshot/2.png)|
|-|-|
|![flutter countdown timer app](./screenshot/3.png)|
